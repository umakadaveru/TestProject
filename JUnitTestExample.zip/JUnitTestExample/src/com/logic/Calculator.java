package com.logic;

public class Calculator {
	
	public static int findMax(int arr[]) {
		int max=0;
		for(int i=0; i<arr.length;i++) {
			if(max<arr[i])
				max=arr[i];
		}
		return max;
	}
	public int sum(int var1, int var2) {
		System.out.println("Adding values: " + var1 + " + " + var2);
		return var1 + var2;
	}


}
