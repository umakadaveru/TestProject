package com.logic;

import java.util.regex.Pattern;

public class Admin {
	
	public static int validateEmail(String email)
	{
		int res=0;
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
                  
       Pattern pat = Pattern.compile(emailRegex);
       if (email == null)
    	  res= 0;
       else if( pat.matcher(email).matches())
    	   res= 1;
       else
    	   res= 0;
       return res;
		
	}

}
