package com.testcase;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.logic.Calculator;

@RunWith(Parameterized.class)
public class TestCalculateLogic {
	
	private int expected;
	private int first;
	private int second;
	
	
    public TestCalculateLogic(int expected, int first, int second) {
		super();
		this.expected = expected;
		this.first = first;
		this.second = second;
	}
	@Test
	public void testFindMax()
	{
    	//new int[]{10,12,3,14};-Annonymous
    	assertEquals(5,Calculator.findMax(new int[] {1,5,2,3}));
    	assertEquals(-3, Calculator.findMax(new int[] {-10,-5,-2,-3}));
	}
	@Test
    public void testSum() {
		Calculator add = new Calculator();
		System.out.println("Addition with parameters : " + first + " and "
				+ second);
		assertEquals(expected, add.sum(first, second));
	}
}
    
